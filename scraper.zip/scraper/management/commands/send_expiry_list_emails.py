from django.core.management.base import BaseCommand, CommandError
from map.send_email import send_email
from map.models import MarkerLine
from datetime import datetime, timedelta


class Command(BaseCommand):
    help = 'Send emails to the users'

    def handle(self, *args, **options):
        markersline = MarkerLine.objects.filter(post_for__gte=datetime.now() - timedelta(days=7))
        for line in markersline:
            try:
                send_email(line.marker.email, "Your post is expiring", f"<p>Expiring Post  {line.title}. Please <a href='https://dvot.org/update-marker/pin?id={line.marker.unique_id}'>click here</a> to update</p>")
            except Exception as e:
                print("email not sent", e)