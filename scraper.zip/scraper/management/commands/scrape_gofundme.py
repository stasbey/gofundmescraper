import re
import asyncio
import httpx
from bs4 import BeautifulSoup
from django.core.management.base import BaseCommand
from scraper.models import *
from django.db import connection
from django.utils.timezone import now
from discord_webhook import DiscordWebhook
import datetime
import uuid
from django.contrib.postgres.search import SearchQuery, SearchVector
from channels.db import database_sync_to_async
from opencage.geocoder import OpenCageGeocode
import requests
import json
import urllib.parse


geocoder = OpenCageGeocode('87f23157e7b9437ea868f54d4a0e2941')


slack_url = "https://hooks.slack.com/services/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"
slack_headers = {'Content-type': 'application/json'}
titles = []

class Command(BaseCommand):
    help = 'Scrape GoFundMe data and store it in the database'

    def handle(self, *args, **options):
        self.stdout.write(self.style.SUCCESS('Scraping GoFundMe data...'))

        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

        loop.run_until_complete(self.scrape_gofundme())

        self.stdout.write(self.style.SUCCESS('Scraping complete.'))

    async def fetch_page(self, url, headers):
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(url, headers=headers, timeout=30)
                response.raise_for_status()
                return response.text
        except httpx.HTTPError as exc:
            print(f"HTTP error while fetching page: {exc}")
            return None
        except httpx.ReadTimeout as exc:
            print(f"Timeout error while fetching page: {exc}")
            return None
        except Exception as exc:
            print(f"An unexpected error occurred: {exc}")
            return None


    async def scrape_page_wrapper(self, url, headers, data):
        await self.scrape_page(url, headers, data)

    async def scrape_page(self, url, headers, data):
        page_content = await self.fetch_page(url, headers)  # Add 'await' here
        if page_content is None:
            return

        soup = BeautifulSoup(page_content, 'html.parser')
        posts = soup.find_all('div', {'data-testid': 'fund-tile'})

        for post in posts:
            page_details_url = post.find('a', {'class': 'fund_tile_card_link'})['href']

            location = post.find('div', {'class': 'fund-item fund-location truncate-single-line'}).get_text()
            latitude, longitude = 51.509865, -0.118092  # Default to London coordinates
            
            

            try:
                page_details_content = await self.fetch_page(page_details_url, headers)
                page_soup = BeautifulSoup(page_details_content, 'html.parser')
                try:
                    title = page_soup.find('h1', {'class': 'p-campaign-title'}).get_text()
                except:
                    title = ''
                
                if title in titles:
                    return
                print(title, headers['Referer'])
                try:
                    description = page_soup.find('div', {'class': 'o-campaign-story'}).get_text().strip()
                except:
                    description = ''
                image = page_soup.find('div', {'class': 'a-image a-image--background'})['style']
                pattern = re.compile(r'\((.*?)\)')
                matches = pattern.findall(image)
                image_url = matches[0]
                try:
                    result = geocoder.geocode(location)
                    if result:
                        location = result[0]['geometry']
                        latitude = location['lat']
                        longitude = location['lng']
                except Exception as e:
                    url = 'https://nominatim.openstreetmap.org/search?q=' + urllib.parse.quote(location) +'&format=jsonv2'
                    response = requests.get(url).json()
                    latitude = response[0]['lat']
                    longitude = response[0]['lon']
                titles.append(title)
                data.append({"title": title, "description": description, "location": location,
                            "latitude": latitude, "longitude": longitude, "image_link": image_url,
                            "link": page_details_url})
            except Exception as e:
                payload = {'text': f'Link not working {e}'}
                response = requests.post(url, headers=headers, data=json.dumps(payload))
                continue

    async def scrape_gofundme(self):
        base_url = 'https://www.gofundme.com/mvc.php?route=categorypages/load_more&page='
        go_fund_me_categories = ['sports-fundraiser','medical-fundraising','other-fundraiser', 'environment-fundraising', 'business-fundraiser',
                                 'community-fundraiser', 'competition-fundraiser', 'event-fundraiser', 'faith-fundraiser',
                                 'family-fundraiser',  'travel-fundraiser', 'volunteer-fundraiser',
                                 'wishes-fundraiser']
        payload = {'text': f'Scraper started'}
        response = requests.post(slack_url, headers=slack_headers, data=json.dumps(payload))
        # List to store data
        data = []

        tasks = []
        for cat in go_fund_me_categories:
            headers = {
                'Host': 'www.gofundme.com',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/119.0',
                'Accept': '*/*',
                'Accept-Language': 'en-GB,en;q=0.5',
                'Accept-Encoding': 'gzip, deflate, br',
                'X-NewRelic-ID': 'UwIGUFdSGwoAVFVRDwY=',
                'X-Requested-With': 'XMLHttpRequest',
                'Connection': 'keep-alive',
                'Referer': f'https://www.gofundme.com/discover/{cat}',
                'Sec-Fetch-Dest': 'empty',
                'Sec-Fetch-Mode': 'cors',
                'Sec-Fetch-Site': 'same-origin',
                'Pragma': 'no-cache',
                'Cache-Control': 'no-cache',
                'TE': 'trailers',
            }
            

            for page_num in range(1, 25):  # Scraping the first 15 pages
                url = f'{base_url}{page_num}&term=&cid=11'
                tasks.append(self.scrape_page_wrapper(url, headers, data))

        await asyncio.gather(*tasks)
        # Save data to the database
        seen = set()
        output_list = []
        for d in data:
            if d['link'] not in seen:
                seen.add(d['link'])
                output_list.append(d)
        duplicate_records = 0
        for row in output_list:
            duplicate_record = await self.save_to_database(row)
            duplicate_records += duplicate_record
        new_list_count = len(output_list) - duplicate_records
        payload = {'text': f'duplicate pins {duplicate_records} and new list found {new_list_count}'}
        response = requests.post(slack_url, headers=slack_headers, data=json.dumps(payload))

        payload = {'text': f'Scraper completed'}
        response = requests.post(slack_url, headers=slack_headers, data=json.dumps(payload))


    @database_sync_to_async
    def save_to_database(self, row):
        unique_id = str(uuid.uuid4().hex)

        with connection.cursor() as cursor:
            cursor.execute("SELECT id FROM map_marker WHERE original_link = %s", (row['link'],))
            pin_records = cursor.fetchall()
            duplicate_record_counts = 0
            print(pin_records, "-------records-----")
            if pin_records:
                duplicate_record_counts += 1
            else:
                # Insert into MapMarker
                # Create a MapMarker instance and save it
                map_marker = Marker(
                    created_at=now(),
                    updated_at=now(),
                    email='support@dvot.org',
                    latitude=float(row['latitude']),
                    longitude=float(row['longitude']),
                    unique_id=str(unique_id),
                    is_active=True,
                    exact=True,
                    obscure=True,
                    address=row['location'],
                    original_link=row['link'],
                )
                map_marker.save()

                # Retrieve the inserted marker_id
                marker_id = map_marker.id

                # Update the location field with geographical coordinates
                cursor.execute(
                    f"UPDATE map_marker SET location = ST_SetSRID(ST_MakePoint({float(row['longitude'])}, {float(row['latitude'])}), 4326) WHERE id = {marker_id}"
                )

                # Insert into MapMarkerline
                price = 0.0  # You can set a default value or handle it as needed
                cleaned_text = re.sub(r'[^A-Za-z0-9 ]+', '', row['description'])

                query_raw = ' | '.join(cleaned_text.split())
                vector = SearchVector("category", "level_1", "level_2", "level_3")
                query = SearchQuery(query_raw, search_type='raw')
                categories = Category_new.objects.annotate(search=vector).filter(search=query).values("id", "category",
                                                                                                    "level_1",
                                                                                                    "level_2",
                                                                                                    "level_3")
                category_list = []
                if categories:
                    for cat in categories:
                        if len(categories[0]['level_3']) > 0:
                            category = f"{cat['category']} > {cat['level_1']} > {cat['level_2']} > {cat['level_3']}"
                        else:
                            category = f"{cat['category']} > {cat['level_1']} > {cat['level_2']}"
                        category_list.append(category)
                else:
                    category_list = ["Others"]

                category = ', '.join(category_list)

                map_markerline = MarkerLine(
                    created_at=now(),
                    updated_at=now(),
                    description=row['title'],
                    post_in=now(),
                    post_for=now() + datetime.timedelta(days=60),
                    post_in_org="0 hr",
                    post_for_org="30 days",
                    title=row['title'],
                    plead=True,
                    help=True,
                    price=price,
                    marker_id=marker_id,
                    category=category,
                    image_link=row['image_link'],
                    is_active=True,
                )
                map_markerline.save()
        return duplicate_record_counts