from django.core.management.base import BaseCommand, CommandError
from map.send_email import send_email
import csv


class Command(BaseCommand):
    help = 'Send emails to the users'

    def handle(self, *args, **options):
        text = ''' <div><img style='width:100px;height:100px' src='https://dvot.org/uploads/datascisive-logo.png'/>  <span style="font-size:100px">  +  <span>  <img style='width:100px;height:100px' src='https://dvot.org/uploads/dvot-logo.png' /></div> <br/><br/> <div>Dear Medical Professional,
                <p>Pardon the long unsolicited email, but <b> I Truly Believe You and Your Patients will find it Very Useful.</b></p>
                <p>By way of introduction, my name is Stanislav Beynarovich; three decades ago I was a refugee from Russia to the U.S. and became a Certified Public Accountant (CPA) to work nearly a decade each as a PricewaterhouseCoopers quant manager, then U.S. Central Banker. Now the founder of a data science & web startup, <b>dataSCIsive</b>. You will find my profile with thousands of global Finance & IT exec followers at</p>
                <p><a href='https://www.LinkedIn.com/in/d8a'>www.LinkedIn.com/in/d8a</a></p>
                <p>I recently saw a  <b>BBC reportage about TikTok donation trend with the app keeping ~80 percent of donations for themselves</b> (which is actually the norm in the charities industry: majority goes to administrative expenses) and realized I can take a minor detour from one of my projects to try to correct this wrong and create a site (not app) which minimizes cost to provide most of donation to the ultimate recipient.</p>
                <p>That’s how dVoT.org was born: <b>“Devote” + Distributed Vouching Technology</b></p>
                <p>If You’d like to help your patients solicit donations directly related to specific needs, You/They can go to <a href="https://www.dvot.org">www.dvot.org</a> to make a simple “Plead” post (PayPal is advised for direct payments, and LinkedIn for trust).</p>
                <p>It’s as easy as clicking on the <a href="https://www.dvot.org">www.dvot.org</a> map, =>    completing a few lines    =>   confirming via email. The post will be immediately visible on the map for people around the world*.</p>
                <p>We recommend that every post (or item w/i a post) relates directly to a patient (psychologically people are more likely to donate to a human, not a typical ambiguous “black box” like a “United Way Charity”).</p>
                <p>Regards and best of luck,</p>
                <p><b>Stanislav (Stas) Beynarovich, CPA</b></p>                                                                             email: s@d8a.si
                <p style="text-align:center"><a href='www.dataSCIsive.com'>www.dataSCIsive.com</a></p></div>
                <hr>
                <p><b>*PLEASE NOTE: Your (publicly listed) email address was among the first randomly selected </b>so you will probably find some bugs (issues with site); please report them to us and we’ll give your listing priority.</p>
                            
                    '''
        file = open('emails_to_send.csv')
        csvreader = csv.reader(file)
        for row in csvreader:
            send_email(row[1], 'Exclusive Invitation to DVoT.org: The First Of Its Kind Direct-Donation Website', text)

