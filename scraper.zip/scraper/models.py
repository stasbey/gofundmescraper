from django.db import models
from django.contrib.gis.geos import Point
from django.contrib.gis.db import models as gis_model
import base64
import hashlib


class BaseModel(models.Model):
    """Base model for each models with common fields."""

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        """Abstract true."""
        abstract = True

#adding category table in database
class Category_new(BaseModel):
    category = models.CharField(max_length=255, null=True, blank=True)
    level_1 = models.CharField(max_length=255, null=True, blank=True)
    level_2 = models.CharField(max_length=255, null=True, blank=True)
    level_3 = models.CharField(max_length=255, null=True, blank=True)
    level_4 = models.CharField(max_length=255, null=True, blank=True)
    level_5 = models.CharField(max_length=255, null=True, blank=True)
    def __str__(self):
     return format(self.category)
    class Meta:
        db_table = 'map_category_new'

class Category_approval(BaseModel):
    category = models.CharField(max_length=255, null=True, blank=True)
    is_approve = models.BooleanField(default=False, null=True, blank=True)
    level_1 = models.CharField(max_length=255, null=True, blank=True)
    level_2 = models.CharField(max_length=255, null=True, blank=True)
    level_3 = models.CharField(max_length=255, null=True, blank=True)
    level_4 = models.CharField(max_length=255, null=True, blank=True)
    level_5 = models.CharField(max_length=255, null=True, blank=True)
    def __str__(self):
     return format(self.category)


#adding materials table in database
class material(BaseModel):
    name = models.CharField(max_length=255)

#adding markers table in database
class Marker(BaseModel):
    """Marker model to manage map markers."""

    email = models.CharField(null=True, blank=True, max_length=255)
    is_active = models.BooleanField(default=False)
    location = gis_model.PointField(srid=4326, null=True, blank=True)
    latitude = models.FloatField()
    longitude = models.FloatField()
    unique_id = models.SlugField(max_length=40, null=True)
    address= models.CharField(max_length=255, blank=True, null=True)
    country = models.CharField(null=True, blank=True, max_length=255)
    city = models.CharField(null=True, blank=True, max_length=255)
    exact = models.BooleanField(default=False)
    obscure = models.BooleanField(default=False)
    state = models.CharField(null=True, blank=True, max_length=255)
    zipcode = models.CharField(null=True, blank=True, max_length=255)
    original_link = models.CharField(null=True, blank=True, max_length=255)
    hash_email =  models.CharField(null=True, blank=True, max_length=255)
    paypal_email =  models.CharField(null=True, blank=True, max_length=1500)

    class Meta:
        db_table = 'map_marker'


    #This function create geoloc location using coordinates which helps in searching
    def wrap_location(self):
        """Save location."""
        print("coordinates:",self.longitude, self.latitude)
        self.location = Point(self.longitude, self.latitude)

    #creating unique id for link of marker
    def create_unique_id(self):
        s = str(self.id)
        s= base64.urlsafe_b64encode(hashlib.md5(s.encode('utf-8')).digest())[:11]
        self.unique_id = s.decode("utf-8")
        self.save()

#Adding table for marker items
class MarkerLine(BaseModel):
    marker = models.ForeignKey(Marker, on_delete=models.CASCADE, default='', null=True, blank=True)
    material = models.ForeignKey(material, on_delete=models.CASCADE, default='', null=True, blank=True)
    color = models.CharField(max_length=255, blank=True, null=True)
    category = models.TextField()
    description = models.TextField(default="")
    post_in=models.DateTimeField(blank=True, null=True)
    post_for=models.DateTimeField(blank=True, null=True)
    diff = models.CharField(null=True, blank=True, max_length=1001)
    post_in_org = models.CharField(null=True, blank=True, max_length=1001)
    post_for_org = models.CharField(null=True, blank=True, max_length=1001)
    title = models.CharField(max_length=1001, blank=True, null=True)
    selling = models.BooleanField(null=True)
    buying = models.BooleanField(null=True)
    price_per_hr = models.FloatField(null=True)
    price = models.FloatField(null=True)
    link = models.CharField(null=True, blank=True, max_length=1000)
    image_link = models.CharField(null=True, blank=True, max_length=1000)
    video_link = models.CharField(null=True, blank=True, max_length=1000)
    potential_item = models.CharField(null=True, blank=True, max_length=1000)
    weight = models.FloatField(null=True)
    width  = models.FloatField(null=True)
    height = models.FloatField(null=True)
    gender = models.CharField(null=True, blank=True, max_length=1000)
    age = models.FloatField(null=True)
    race = models.CharField(null=True, blank=True, max_length=1000)
    experience = models.CharField(null=True, blank=True, max_length=1000)
    working_hours=models.CharField(null=True, blank=True, max_length=1000)
    work_from=models.CharField(null=True, blank=True, max_length=1000)
    sender_email=models.CharField(null=True, blank=True, max_length=1000)
    receiver_email=models.CharField(null=True, blank=True, max_length=1000)
    instagram=models.CharField(null=True, blank=True, max_length=1000)
    close_ad=models.BooleanField(null=True, default=False) 
    interest=models.CharField(null=True, blank=True, max_length=1000)
    help = models.BooleanField(null=True)
    plead = models.BooleanField(null=True)
    currency = models.CharField(null=True, blank=True, max_length=1000)
    is_active = models.BooleanField(default=False)
    original_link = models.CharField(null=True, blank=True, max_length=1000)

    class Meta:
        db_table = 'map_markerline'


class MarkerEmail(BaseModel):
    sender_email=models.CharField(null=True, blank=True, max_length=1000)
    receiver_email=models.CharField(null=True, blank=True, max_length=1000)
    rating_email_sent=models.BooleanField(null=True)   
    markerline = models.ForeignKey(MarkerLine, on_delete=models.CASCADE, default='', null=True, blank=True)

class MarkerRating(BaseModel):
    comment=models.TextField(default="")
    min_rating=models.BooleanField(null=True)
    max_rating=models.BooleanField(null=True)
    email=models.CharField(null=True, blank=True, max_length=1000)
    markerline = models.ForeignKey(MarkerLine, on_delete=models.CASCADE, default='', null=True, blank=True)

class Questions(BaseModel):
    questions = models.CharField(null=True, blank=True, max_length=1000)

class InterestedEmail(BaseModel):
    markerline = models.ForeignKey(MarkerLine, on_delete=models.CASCADE, default='', null=True, blank=True)
    email = models.CharField(null=True, blank=True, max_length=1000)

class TimeQuestion(BaseModel):
    email = models.CharField(null=True, blank=True, max_length=1000)
    questions = models.CharField(null=True, blank=True, max_length=1000)
    answers = models.CharField(null=True, blank=True, max_length=1000)





